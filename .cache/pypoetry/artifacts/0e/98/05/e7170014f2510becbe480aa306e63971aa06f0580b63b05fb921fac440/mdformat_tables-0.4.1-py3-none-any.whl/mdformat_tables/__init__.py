"""An mdformat plugin for rendering tables."""

__version__ = "0.4.1"

from .plugin import POSTPROCESSORS, RENDERERS, update_mdit  # noqa: F401
