__all__ = ("file", "text")
__version__ = "0.7.16"  # DO NOT EDIT THIS LINE MANUALLY. LET bump2version UTILITY DO IT

from mdformat._api import file, text
